﻿using SessionizingService;
using System;
using System.Collections.Generic;
using Xunit;


namespace SessionizingServiceTesting
{
    public class SessionizingQueriesTests
    {
        #region Create data

        #region Session length data
        public static Dictionary<string, List<long>> sessionLengthValues = new Dictionary<string, List<long>> { { "site1", new List<long>() { 5, 6 } }, { "site2", new List<long>() { 8, 9, 10, 11, 12, 13 } }, { "site3", new List<long>() { 5 } },{ "site5", new List<long>() { long.MaxValue, long.MaxValue } }, { "site4", new List<long>() { } } };

        public static IEnumerable<object[]> SessionList = new List<object[]>
        {
            new object[] { sessionLengthValues , "site1",2},
            new object[] { sessionLengthValues , "site2",6},
            new object[] { sessionLengthValues , "site3",1}
        };

        public static IEnumerable<object[]> SessionMedianList = new List<object[]>
        {
            new object[] { sessionLengthValues , "site1",5.5},
            new object[] { sessionLengthValues , "site2",10.5},
            new object[] { sessionLengthValues , "site3",5},
            new object[] { sessionLengthValues , "site5", long.MaxValue }
        };

        public static IEnumerable<object[]> EmptySessionList = new List<object[]>
        {
            new object[] { sessionLengthValues , "site4",0}
        };

        public static IEnumerable<object[]> NoSiteKey = new List<object[]>
        {
            new object[] { sessionLengthValues , "siteNotExist", 0}
        };

        public static IEnumerable<object[]> EmptySiteKey = new List<object[]>
        {
            new object[] { sessionLengthValues , String.Empty, 0}
        };
        #endregion

        #region visitors Data
        public static Dictionary<string, HashSet<string>> visitorsValues = new Dictionary<string, HashSet<string>> { { "visitor1", new HashSet<string>() { "site1", "site2", "site3" } }, { "visitor2", new HashSet<string>() { "site1", "site5" } }, { "visitor3", new HashSet<string>() { "site1", "site2", "site3", "site4", "site5", "site6" } }, { "visitor4", new HashSet<string>() { } } };

        public static IEnumerable<object[]> VisitedSitesList = new List<object[]>
        {
            new object[] { visitorsValues, "visitor1",3},
            new object[] { visitorsValues, "visitor2",2},
            new object[] { visitorsValues, "visitor3",6}
        };

        public static IEnumerable<object[]> EmptyVisitedList = new List<object[]>
        {
            new object[] { visitorsValues, "visitor4",0}
        };

        public static IEnumerable<object[]> NoVisitorKey = new List<object[]>
        {
            new object[] { visitorsValues, "visitorNotExist", 0}
        };

        public static IEnumerable<object[]> EmptyVisitorKey = new List<object[]>
        {
            new object[] { visitorsValues, String.Empty, 0}
        };

        #endregion
        
        #endregion

        #region Nominal test

        #region GetSessionNum Query

        [Theory]
        [MemberData(nameof(SessionList))]
        public void GetSessionNum_ShouldReturnExpectedResult(Dictionary<string, List<long>> values, string site, int expectedResult)
        {
            //arrange
            var query = new SessionizingQueries();

            //act
            var result = query.GetSessionsNum(site, values);

            //assert
            Assert.Equal(expectedResult, result);
        }

        #endregion

        #region GetUniqueVisitedSites Query
        [Theory]
        [MemberData(nameof(VisitedSitesList))]
        public void GetUniqueVisitedSites_ShouldReturnExpectedResult(Dictionary<string, HashSet<string>> values, string visitor, int expectedResult)
        {
            //arrange
            var query = new SessionizingQueries();

            //act
            var result = query.GetUniqueVisitedSites(visitor, values);

            //assert
            Assert.Equal(expectedResult, result);
        }
        #endregion

        #region GetMedianSessionLength Query
        [Theory]
        [MemberData(nameof(SessionMedianList))]
        public void GetMedianSessionLength_ShouldReturnExpectedResult(Dictionary<string, List<long>> values, string site, double expectedResult)
        {
            //arrange
            var query = new SessionizingQueries();

            //act
            var result = query.GetMedianSessionLength(site, values);

            //assert
            Assert.Equal(expectedResult, result);
        }
        #endregion

        #endregion

        #region Non nominal tests

        #region GetSessionNum Query
        [Theory]
        [MemberData(nameof(EmptySessionList))]
        public void GetSessionNum_EmptySessionsList_ShouldReturnZero(Dictionary<string, List<long>> values, string site, int expectedResult)
        {
            //arrange
            var query = new SessionizingQueries();

            //act
            var result = query.GetSessionsNum(site, values);

            //assert
            Assert.Equal(expectedResult, result);
        }

        [Theory]
        [MemberData(nameof(NoSiteKey))]
        public void GetSessionNum_NoSiteKey_ShouldReturnZero(Dictionary<string, List<long>> values, string site, int expectedResult)
        {
            //arrange
            var query = new SessionizingQueries();

            //act
            var result = query.GetSessionsNum(site, values);

            //assert
            Assert.Equal(expectedResult, result);
        }

        [Theory]
        [MemberData(nameof(EmptySiteKey))]
        public void GetSessionNum_EmptyStringSiteKey_ShouldReturnZero(Dictionary<string, List<long>> values, string site, int expectedResult)
        {
            //arrange
            var query = new SessionizingQueries();

            //act
            var result = query.GetSessionsNum(site, values);

            //assert
            Assert.Equal(expectedResult, result);
        }

        [Theory]
        [InlineData("someSite")]
        public void GetSessionNum_MapEmpty_ShouldReturnZero(string site)
        {
            // arrange
            Dictionary<string, List<long>> values = new Dictionary<string, List<long>>();
            var query = new SessionizingQueries();

            //act
            var result = query.GetSessionsNum(site, values);

            //assert
            Assert.Equal(0, result);
        }

        [Theory]
        [InlineData(null)]
        public void GetSessionNum_siteKeyIsNull_ShouldThrowException(string site)
        {
            // arrange
            Dictionary<string, List<long>> values = new Dictionary<string, List<long>>();
            var query = new SessionizingQueries();

            //act + assert
            Assert.Throws<ArgumentNullException>(() => query.GetSessionsNum(site, values));
        }
        #endregion

        #region GetMedianSessionLength Query
        [Theory]
        [MemberData(nameof(EmptySessionList))]
        public void GetMedianSessionLength_EmptySessionsList_ShouldReturnZero(Dictionary<string, List<long>> values, string site, int expectedResult)
        {
            //arrange
            var query = new SessionizingQueries();

            //act
            var result = query.GetMedianSessionLength(site, values);

            //assert
            Assert.Equal(expectedResult, result);
        }

        [Theory]
        [MemberData(nameof(NoSiteKey))]
        public void GetMedianSessionLength_NoSiteKey_ShouldReturnZero(Dictionary<string, List<long>> values, string site, int expectedResult)
        {
            //arrange
            var query = new SessionizingQueries();

            //act
            var result = query.GetMedianSessionLength(site, values);

            //assert
            Assert.Equal(expectedResult, result);
        }

        [Theory]
        [MemberData(nameof(EmptySiteKey))]
        public void GetMedianSessionLength_EmptyStringSiteKey_ShouldReturnZero(Dictionary<string, List<long>> values, string site, int expectedResult)
        {
            //arrange
            var query = new SessionizingQueries();

            //act
            var result = query.GetMedianSessionLength(site, values);

            //assert
            Assert.Equal(expectedResult, result);
        }

        [Theory]
        [InlineData("someSite")]
        public void GetMedianSessionLength_MapEmpty_ShouldReturnZero(string site)
        {
            // arrange
            Dictionary<string, List<long>> values = new Dictionary<string, List<long>>();
            var query = new SessionizingQueries();

            //act
            var result = query.GetMedianSessionLength(site, values);

            //assert
            Assert.Equal(0, result);
        }

        [Theory]
        [InlineData(null)]
        public void GetMedianSessionLength_siteKeyIsNull_ShouldThrowException(string site)
        {
            // arrange
            Dictionary<string, List<long>> values = new Dictionary<string, List<long>>();
            var query = new SessionizingQueries();

            //act + assert
            Assert.Throws<ArgumentNullException>(() => query.GetMedianSessionLength(site, values));
        }
        #endregion

        #region GetUniqueVisitedSites Query
        [Theory]
        [MemberData(nameof(EmptyVisitedList))]
        public void GetUniqueVisitedSites_EmptySessionsList_ShouldReturnZero(Dictionary<string, HashSet<string>> values, string visitor, int expectedResult)
        {
            //arrange
            var query = new SessionizingQueries();

            //act
            var result = query.GetUniqueVisitedSites(visitor, values);

            //assert
            Assert.Equal(expectedResult, result);
        }

        [Theory]
        [MemberData(nameof(NoVisitorKey))]
        public void GetUniqueVisitedSites_NoSiteKey_ShouldReturnZero(Dictionary<string, HashSet<string>> values, string visitor, int expectedResult)
        {
            //arrange
            var query = new SessionizingQueries();

            //act
            var result = query.GetUniqueVisitedSites(visitor, values);

            //assert
            Assert.Equal(expectedResult, result);
        }

        [Theory]
        [MemberData(nameof(EmptyVisitorKey))]
        public void GetUniqueVisitedSites_EmptyStringSiteKey_ShouldReturnZero(Dictionary<string, HashSet<string>> values, string visitor, int expectedResult)
        {
            //arrange
            var query = new SessionizingQueries();

            //act
            var result = query.GetUniqueVisitedSites(visitor, values);

            //assert
            Assert.Equal(expectedResult, result);
        }

        [Theory]
        [InlineData("someVisitor")]
        public void GetUniqueVisitedSites_MapEmpty_ShouldReturnZero(string visitor)
        {
            // arrange
            Dictionary<string, HashSet<string>> values = new Dictionary<string, HashSet<string>>();
            var query = new SessionizingQueries();

            //act
            var result = query.GetUniqueVisitedSites(visitor, values);

            //assert
            Assert.Equal(0, result);
        }

        [Theory]
        [InlineData(null)]
        public void GetUniqueVisitedSites_visitorKeyIsNull_ShouldThrowException(string visitor)
        {
            // arrange
            Dictionary<string, HashSet<string>> values = new Dictionary<string, HashSet<string>>();
            var query = new SessionizingQueries();

            //act + assert
            Assert.Throws<ArgumentNullException>(() => query.GetUniqueVisitedSites(visitor, values));
        }
        #endregion

        #endregion

    }
}
