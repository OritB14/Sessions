﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using FakeItEasy;
using SessionizingService;


namespace SessionizingServiceTesting
{
    public class DataManagerTests
    {

        [Theory]
        [InlineData("site3",6,"")]
        [InlineData("site1",0, "No records of site: site1 \n")]
        [InlineData("site2",int.MaxValue, "")]
        public void GetSessionNum_ShouldReturnExpectedResult(string site,int expectedResult, string message)
        {
            //arrange
            var queries = A.Fake<ISessionizingQueries>();
            var manager = new DataManager(queries);
            
            A.CallTo(() => queries.GetSessionsNum(site, manager.SiteSessionLengthMap)).Returns(expectedResult);

            //act
            var resMessage = String.Empty;
            var result = manager.GetSessionsNum(site, out resMessage);

            //assert
            A.CallTo(() => queries.GetSessionsNum(A<string>.Ignored, manager.SiteSessionLengthMap)).MustHaveHappened();
            Assert.Equal(expectedResult, result);
            Assert.Equal(message, resMessage);
        }


        [Theory]
        [InlineData("visitor5", 20, "")]
        [InlineData("visitor3", 0, "No records of visitor: visitor3 \n")]
        [InlineData("visitor200", int.MaxValue, "")]
        public void GetUniqueVisitedSites_ShouldReturnExpectedResult(string visitor, int expectedResult, string message)
        {
            //arrange
            var queries = A.Fake<ISessionizingQueries>();
            var manager = new DataManager(queries);

            A.CallTo(() => queries.GetUniqueVisitedSites(visitor, manager.VisitorTrafficMap)).Returns(expectedResult);

            //act
            var resMessage = String.Empty;
            var result = manager.GetUniqueVisitedSites(visitor, out resMessage);

            //assert
            A.CallTo(() => queries.GetUniqueVisitedSites(visitor, manager.VisitorTrafficMap)).MustHaveHappened();
            Assert.Equal(expectedResult, result);
            Assert.Equal(message, resMessage);
        }

        [Theory]
        [InlineData("site3", 105.5, "")]
        [InlineData("site1", 0, "")]
        [InlineData("site2", double.MaxValue, "")]
        public void GetMedianSessionLength_ShouldReturnExpectedResult(string site, double expectedResult, string message)
        {
            //arrange
            var queries = A.Fake<ISessionizingQueries>();
            var manager = new DataManager(queries);

            A.CallTo(() => queries.GetMedianSessionLength(site, manager.SiteSessionLengthMap)).Returns(expectedResult);

            //act
            var resMessage = String.Empty;
            var result = manager.GetMedianSessionLength(site, out resMessage);

            //assert
            A.CallTo(() => queries.GetMedianSessionLength(site, manager.SiteSessionLengthMap)).MustHaveHappened();
            Assert.Equal(expectedResult, result);
            Assert.Equal(message, resMessage);
        }



        [Theory]
        [InlineData("Exception with message:" ,0)]
        public void GetMedianSessionLength_InnerException_ShouldReturnZeroAndExceptionMessage(string message, double expectedResult)
        {
            //arrange
            var queries = A.Fake<ISessionizingQueries>();
            var manager = new DataManager(queries);

            A.CallTo(() => queries.GetMedianSessionLength(A<string>.Ignored, manager.SiteSessionLengthMap)).Throws<Exception>();

            //act + assert
            var resMessage = String.Empty;
            var result = manager.GetMedianSessionLength("someSite", out resMessage);

            //assert
            A.CallTo(() => queries.GetMedianSessionLength(A<string>.Ignored, manager.SiteSessionLengthMap)).MustHaveHappened();
            Assert.StartsWith(message,resMessage);
            Assert.Equal(expectedResult,result);
        }

        [Theory]
        [InlineData("Exception with message:", 0)]
        public void GetSessionsNum_InnerException_ShouldReturnZeroAndExceptionMessage(string message, int expectedResult)
        {
            //arrange
            var queries = A.Fake<ISessionizingQueries>();
            var manager = new DataManager(queries);

            A.CallTo(() => queries.GetSessionsNum(A<string>.Ignored, manager.SiteSessionLengthMap)).Throws<Exception>();

            //act + assert
            var resMessage = String.Empty;
            var result = manager.GetSessionsNum("someSite", out resMessage);

            //assert
            A.CallTo(() => queries.GetSessionsNum(A<string>.Ignored, manager.SiteSessionLengthMap)).MustHaveHappened();
            Assert.StartsWith(message, resMessage);
            Assert.Equal(expectedResult, result);
        }


        [Theory]
        [InlineData("Exception with message:", 0)]
        public void GetUniqueVisitedSites_InnerException_ShouldReturnZeroAndExceptionMessage(string message, int expectedResult)
        {
            //arrange
            var queries = A.Fake<ISessionizingQueries>();
            var manager = new DataManager(queries);

            A.CallTo(() => queries.GetUniqueVisitedSites(A<string>.Ignored, manager.VisitorTrafficMap)).Throws<Exception>();

            //act + assert
            var resMessage = String.Empty;
            var result = manager.GetUniqueVisitedSites("someVisitor", out resMessage);

            //assert
            A.CallTo(() => queries.GetUniqueVisitedSites(A<string>.Ignored, manager.VisitorTrafficMap)).MustHaveHappened();
            Assert.StartsWith(message, resMessage);
            Assert.Equal(expectedResult, result);
        }
    }
}
