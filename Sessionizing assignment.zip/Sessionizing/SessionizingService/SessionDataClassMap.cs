﻿using CsvHelper.Configuration;

namespace SessionizingService
{
    public class SessionDataClassMap : ClassMap<SessionData>
    {
        public SessionDataClassMap()
        {
            Map(m => m.VisitorId).Index(0);
            Map(m => m.SiteUrl).Index(1);
            Map(m => m.PageViewUrl).Index(2);
            Map(m => m.Timestamp).Index(3);
        }


    }
}
