﻿using System.Collections.Generic;

namespace SessionizingService
{
    public interface IDataManager
    {
        void ProcessFile(string path);
        void AnalyzingData();
        int GetSessionsNum(string siteUrl, out string message);
        double GetMedianSessionLength(string siteUrl, out string message);
        int GetUniqueVisitedSites(string visitorId, out string message);
    }
}
