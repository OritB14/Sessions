﻿using System.Collections.Generic;

namespace SessionizingService
{
    public interface ISessionizingQueries
    {
        int GetSessionsNum(string siteUrl, Dictionary<string, List<long>> SiteSessionLengthMap);
        double GetMedianSessionLength(string siteUrl, Dictionary<string, List<long>> SiteSessionLengthMap);
        int GetUniqueVisitedSites(string visitorId, Dictionary<string, HashSet<string>> VisitorTrafficMap);
    }
}