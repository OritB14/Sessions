﻿using CsvHelper;
using CsvHelper.Configuration;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;


namespace SessionizingService
{
    public class DataManager : IDataManager
    {
        #region ctor
        public DataManager(ISessionizingQueries queries)
        {
            MaxSessionSeconds = 1800;
            Queries = queries;
            Records = new List<SessionData>();
            SiteSessionLengthMap = new Dictionary<string, List<long>>();
            VisitorTrafficMap = new Dictionary<string, HashSet<string>>();
            SessionInfoMap = new Dictionary<string, Dictionary<string, SortedList<long, long>>>();
        }
        #endregion

        #region properties
        internal readonly long MaxSessionSeconds;
        ISessionizingQueries Queries { get; set; }
        List<SessionData> Records { get; set; }
        public Dictionary<string, List<long>> SiteSessionLengthMap { get; set; }
        public Dictionary<string, HashSet<string>> VisitorTrafficMap { get; set; }
        internal Dictionary<string, Dictionary<string, SortedList<long, long>>> SessionInfoMap { get; set; }
        #endregion

        #region Queries
        public int GetSessionsNum(string siteUrl, out string message)
        {
            try
            {
                message = String.Empty;
                var result =  Queries.GetSessionsNum(siteUrl, SiteSessionLengthMap);
                if (result == 0)
                {
                    message = $"No records of site: {siteUrl} \n";
                }
                return result;
            }
            catch (Exception ex)
            {
                message = $"Exception with message:{ex.Message}";
                return 0;
            }
        }

        public double GetMedianSessionLength(string siteUrl, out string message)
        {
            try
            {
                message = String.Empty;
                return Queries.GetMedianSessionLength(siteUrl, SiteSessionLengthMap);
            }
            catch (Exception ex)
            {
                message = $"Exception with message:{ex.Message}";
                return 0;
            }
        }
         
        public int GetUniqueVisitedSites(string visitorId, out string message)
        {
            try
            {
                message = String.Empty;
                var result = Queries.GetUniqueVisitedSites(visitorId, VisitorTrafficMap);
                if (result == 0)
                {
                    message = $"No records of visitor: {visitorId} \n";
                }
                return result;
            }
            catch (Exception ex)
            {
                message = $"Exception with message:{ex.Message}";
                return 0;
            }
        }
        #endregion

        #region Data initialization functions
        public void ProcessFile(string path)
        {
            using (var streamReader = new StreamReader(path))
            {
                var csvConfig = new CsvConfiguration(CultureInfo.InvariantCulture)
                {
                    HasHeaderRecord = false
                };
                using (var csvReader = new CsvReader(streamReader, csvConfig))
                {
                    csvReader.Context.RegisterClassMap<SessionDataClassMap>();
                    Records.AddRange(csvReader.GetRecords<SessionData>().ToList());
                }
            }
        }

        public void AnalyzingData()
        {
            foreach (SessionData s in Records)
            {
                SetVisitorsMap(s);
                SetSessionInfoMap(s);
            }
            SetSessionLengthMap();
            SortSessionLength();
        }

        private void SetVisitorsMap(SessionData s)
        {
            if (!VisitorTrafficMap.ContainsKey(s.VisitorId))
            {
                VisitorTrafficMap.Add(s.VisitorId, new HashSet<string>());
            }
            VisitorTrafficMap[s.VisitorId].Add(s.SiteUrl);
        }

        private void SetSessionLengthMap()
        {
            foreach (var site in SessionInfoMap)
            {
                foreach (var visitor in site.Value)
                {
                    for (int i = 0; i < visitor.Value.Count - 1; i++)
                    {
                        long lengthDiff = GetTimestampDiff(visitor.Value.Keys[i], visitor.Value.Keys[i + 1]);

                        if (IsNewSession(lengthDiff))
                        {
                            AddToSiteSessionLengthDic(site.Key, visitor.Value.Values[i]);
                        }
                        else
                        {
                            visitor.Value[visitor.Value.Keys[i + 1]] = visitor.Value.Values[i] + lengthDiff;
                        }
                    }
                    AddToSiteSessionLengthDic(site.Key, visitor.Value.Values.Last());
                }
            }
        }

        private void SetSessionInfoMap(SessionData s)
        {
            //first value for site + user
            if (!SessionInfoMap.ContainsKey(s.SiteUrl)) // new siteUrl
            {
                SessionInfoMap.Add(s.SiteUrl, new Dictionary<string, SortedList<long, long>>());
                SessionInfoMap[s.SiteUrl].Add(s.VisitorId, new SortedList<long, long>());
                SessionInfoMap[s.SiteUrl][s.VisitorId].Add(s.Timestamp, 0);
            }
            else // siteUrl exists in dictionary
            {
                if (!SessionInfoMap[s.SiteUrl].ContainsKey(s.VisitorId)) // new visitor
                {
                    SessionInfoMap[s.SiteUrl].Add(s.VisitorId, new SortedList<long, long>());
                    SessionInfoMap[s.SiteUrl][s.VisitorId].Add(s.Timestamp, 0);
                }
                else //visitor exists in dictionary  
                {
                    SessionInfoMap[s.SiteUrl][s.VisitorId].Add(s.Timestamp, 0);
                }
            }
        }
        #endregion


        #region Utility functions
        private void SortSessionLength()
        {
            Parallel.ForEach(SiteSessionLengthMap, site =>
            {
                site.Value.Sort();
            });
            //foreach (var site in SiteSessionLengthMap)
            //{
            //    site.Value.Sort();
            //}
        }

        private bool IsNewSession(long length)
        {
            return length > MaxSessionSeconds ? true : false;
        }

        private long GetTimestampDiff(long timestamp1, long timestamp2)
        {
            return timestamp2 - timestamp1;
        }

        private void AddToSiteSessionLengthDic(string key, long v)
        {
            if (SiteSessionLengthMap.ContainsKey(key))
            {
                SiteSessionLengthMap[key].Add(v);//should be length value - todo: or get by key
            }
            else //new entry
            {
                SiteSessionLengthMap.Add(key, new List<long>() { v });//should be length value - todo: or get by key
            }
        }
        #endregion
    }
}
