﻿namespace SessionizingService
{
    public class SessionData
    {
        public string VisitorId { get; set; }
        public string SiteUrl { get; set; }
        public string PageViewUrl { get; set; }
        public long Timestamp { get; set; }
    }
}
