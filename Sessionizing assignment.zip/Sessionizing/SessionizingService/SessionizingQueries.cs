﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace SessionizingService
{
    public class SessionizingQueries : ISessionizingQueries
    {
        public double GetMedianSessionLength(string siteUrl, Dictionary<string, List<long>> siteSessionLengthMap)
        {
            return siteSessionLengthMap.ContainsKey(siteUrl) ? CalcMedian(siteUrl, siteSessionLengthMap) : 0;
        }

        public int GetSessionsNum(string siteUrl, Dictionary<string, List<long>> SiteSessionLengthMap)
        {
            return SiteSessionLengthMap.ContainsKey(siteUrl) ? SiteSessionLengthMap[siteUrl].Count : 0;
        }

        public int GetUniqueVisitedSites(string visitorId, Dictionary<string, HashSet<string>> VisitorTrafficMap)
        {
            return VisitorTrafficMap.ContainsKey(visitorId) ? VisitorTrafficMap[visitorId].Count : 0;
        }

        private double CalcMedian(string siteUrl, Dictionary<string, List<long>> siteSessionLengthMap)
        {
            try
            {
                var sessionCount = siteSessionLengthMap[siteUrl].Count();
                if (sessionCount <= 1)
                {
                    return sessionCount == 1 ? Convert.ToDouble(siteSessionLengthMap[siteUrl].ElementAt(0)) : 0;
                }
                var halfIndex = siteSessionLengthMap[siteUrl].Count() / 2;
                if ((sessionCount % 2) == 0)
                {
                    return (Convert.ToDouble(siteSessionLengthMap[siteUrl].ElementAt(halfIndex)) +
                        Convert.ToDouble(siteSessionLengthMap[siteUrl].ElementAt(halfIndex - 1))) / 2;
                }
                return siteSessionLengthMap[siteUrl].ElementAt(halfIndex);
            }
            catch (Exception ex)
            {
                throw new Exception($" CalcMedian: {siteUrl}, Error: {ex.Message}");
            }
        }
    }
}
