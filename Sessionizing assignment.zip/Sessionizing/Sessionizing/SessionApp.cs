﻿using CommandLine;
using Sessionizing.CliParser;
using SessionizingService;
using System;
using System.IO;
using System.Net.Mime;

namespace Sessionizing
{
    internal class SessionApp
    {
        public SessionApp(IDataManager dataManager)
        {
            Manager = dataManager;
            DisplayMenu = true;
        }
        private IDataManager Manager { get; set; }
        private bool DisplayMenu { get; set; }
        public void Run()
        {
            Console.WriteLine("--- S E S S I O N I Z I N G ---\n");
            Console.WriteLine("Close program with: exit \n");
            Console.WriteLine("Please insert: input -i <input file(s) path> you wish to analyze.\n");

            string[] inputArr = Console.ReadLine()?.Split(' ');
            
            if (inputArr.Length == 0)
            {
                Console.WriteLine("Invalid args");
                return;
            }

            while (true)
            {
                ConfigureParser(inputArr);
                if (DisplayMenu)    
                { 
                    DisplayQueryMenu(); 
                }
                inputArr = Console.ReadLine().Split(' ');
                if (inputArr[0].Equals("exit", StringComparison.OrdinalIgnoreCase))
                {
                    break; 
                }
            }
        }

        void ConfigureParser(string[] inputArr)
        {
            Parser.Default.ParseArguments<SessionsLengthMedianCommand, SessionsNumCommand,
                           UniqueVisitedSitesNumCommand, ImportFilesCommand>(inputArr)
                         .WithParsed<ICommand>(t => t.ExecuteServiceQuery(Manager));
        }

        void DisplayQueryMenu()
        {
            Console.WriteLine("\n\tQUERIES OPTIONS: \n ");
            Console.WriteLine("\tNum_sessions -s <site name>: \t\t\t Get a site Sessions number");
            Console.WriteLine("\tMedian_session_length -s <site name>:   \t Get a site sessions length median");
            Console.WriteLine("\tNum_unique_visited_sites -v <visitorId>:\t Get a visitor unique visited sites number");
            Console.WriteLine("\tExit: \t\t\t\t\t\t Exit program\n");
            DisplayMenu = false;
        }
    }
}
