﻿using System;
using CommandLine;
using SessionizingService;

namespace Sessionizing.CliParser
{
    [Verb("Median_session_length", HelpText = "Get a site sessions length median")]
    internal class SessionsLengthMedianCommand : ICommand
    {
        [Option('s', "site", Required = true, HelpText = "The site of which you wish to get the session median")]
        public string Site { get; set; }
        public void ExecuteServiceQuery(IDataManager manager)
        {
            try
            {
                var result = manager.GetMedianSessionLength(Site, out string message);
                if (message.Equals(string.Empty))
                    Console.WriteLine($"{Site} median session length = {result}");
                else
                    Console.WriteLine($"{message}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception message: {ex.Message}");
            }
        }
    }
}
