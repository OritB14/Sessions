﻿using CommandLine;
using SessionizingService;
using System;

namespace Sessionizing.CliParser
{
    [Verb("Num_unique_visited_sites", HelpText = "Save all your commits to the cloud")]
    internal class UniqueVisitedSitesNumCommand : ICommand
    {
        [Option('v', "visitorId", Required = true, HelpText = "The visitorId you wish to get the unique visited sites of.")]
        public string VisitorId { get; set; }
        string message { get; set; }
        public void ExecuteServiceQuery(IDataManager manager)
        {
            try
            {
                var result = manager.GetUniqueVisitedSites(VisitorId, out string message);
                if (message.Equals(String.Empty))
                    Console.WriteLine($"Num of unique sites for {VisitorId} = {result}");
                else
                    Console.WriteLine($"{message}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception message: {ex.Message}");
            }
        }
    }
}
