﻿using SessionizingService;

namespace Sessionizing.CliParser
{
     interface ICommand
    {
        void ExecuteServiceQuery(IDataManager manager);
    }
}
