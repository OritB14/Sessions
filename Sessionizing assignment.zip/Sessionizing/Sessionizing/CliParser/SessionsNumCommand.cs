﻿using System;
using CommandLine;
using SessionizingService;

namespace Sessionizing.CliParser
{
    [Verb("Num_sessions", HelpText = "Get a site Sessions number")]
    internal class SessionsNumCommand : ICommand
    {
        [Option('s', "site", HelpText = "The site of which you wish to get the session number ")]
        public string Site { get; set; }

        public void ExecuteServiceQuery(IDataManager manager)
        {
            try
            {
                var result = manager.GetSessionsNum(Site, out string message);
                if (message.Equals(string.Empty))
                    Console.WriteLine($"Num sessions for site {Site} = {result}");
                else
                    Console.WriteLine($"{message}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception message: {ex.Message}");
            }
        }
    }
}
