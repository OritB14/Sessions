﻿using CommandLine;
using SessionizingService;
using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;

namespace Sessionizing.CliParser
{
    [Verb("input", HelpText = "Input files to analyze.")]
    internal class ImportFilesCommand : ICommand
    {
        [Option('i', "inputFiles", 
            Required = true, HelpText = "Input file(s) to process")]
        public IEnumerable<string> InputFiles { get; set; }
        public void ExecuteServiceQuery(IDataManager manager)
        {
            try
            {
                Console.WriteLine($"\n\t\tImporting files..");
                if (InputFiles.ToArray()[0].Equals("local"))
                {
                    var inputFilesPath = GetLocalInputFilePath();
                    foreach (string file in Directory.EnumerateFiles(inputFilesPath, "*.csv"))
                    {
                        manager.ProcessFile(file);
                    }
                }
                else
                {
                    foreach (string filePath in InputFiles)
                    {
                        if (!File.Exists(filePath))
                        {
                            Console.WriteLine($"{filePath} is not a valid file or directory.");
                        }
                        else
                        {
                            manager.ProcessFile(filePath);
                        }
                    }
                }

                Console.WriteLine($"\t\tAnalyzing data..");
                manager.AnalyzingData();
                Console.WriteLine($"\t\tAnalyzing complete");
            }
            catch (Exception ex)
            {
                Console.WriteLine($" Error in import input file(s) to analyze, Info: {ex.Message}");
            }
        }

        string GetLocalInputFilePath()
        {
            var basePath = AppDomain.CurrentDomain.BaseDirectory;
            var solutionPath = Path.GetFullPath(Path.Combine(basePath, @"..\..\..\..\"));
            return solutionPath + @"Input\"; ;
        }
    }
}
