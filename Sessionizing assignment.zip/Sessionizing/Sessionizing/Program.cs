﻿using Autofac;
using SessionizingService;
using System;

namespace Sessionizing
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                CompositionRoot().Resolve<SessionApp>().Run();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception error message: {ex.Message}");
            }
        }

        private static IContainer CompositionRoot()
        {
            var builder = new ContainerBuilder();
            builder.RegisterType<SessionApp>();
            builder.RegisterType<DataManager>().As<IDataManager>().SingleInstance();
            builder.RegisterType<SessionizingQueries>().As<ISessionizingQueries>();
            return builder.Build();
        }

    }
}
